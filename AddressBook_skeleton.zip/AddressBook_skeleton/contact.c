#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"

void listContacts(AddressBook *addressBook) 
{
    /* Define the logic for print the contacts */
    //printf("%s\n", addressBook->contacts[addressBook->contactCount].name);
}

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
    populateAddressBook(addressBook);

    // Load contacts from file during initialization (After files)
    //loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) {
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}


void createContact(AddressBook *addressBook)
{
    /* Define the logic to create a Contacts */

    // Read the name from the user
    scanf(" %[^\n]", addressBook->contacts[addressBook->contactCount].name);

    char number[11];
    // Read the contact
    // - Check whether the count is 10 or not
    // - Check all 10 characters are digits or not.
    // - Check the given number is already exist or not
    char mail[20];
    // Read the email ID
    // - Check whether the character array contains lowercase, digits and special characters or not
    // - Check whether char - @ and .com is present or not

    // Increment the contact count.
}

void searchContact(AddressBook *addressBook) 
{
    /* Define the logic for search */
}

void editContact(AddressBook *addressBook)
{
    /* Define the logic for Editcontact */

}

void deleteContact(AddressBook *addressBook)
{
    /* Define the logic for deletecontact */

}
