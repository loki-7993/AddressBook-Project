#include <stdio.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook) {
  
}

void loadContactsFromFile(AddressBook *addressBook) {
    
}
